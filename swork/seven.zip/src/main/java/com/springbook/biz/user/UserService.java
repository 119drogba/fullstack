package com.springbook.biz.user;

import java.util.List;

public interface UserService {

	public UserVO login(UserVO vo);
	public List<UserVO> getUserList();
	public void userUpdate(UserVO vo);
	public void userInsert(UserVO vo);
	public void userDelete(UserVO vo);

}
