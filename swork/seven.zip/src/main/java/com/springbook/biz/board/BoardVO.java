package com.springbook.biz.board;

import java.sql.Date;

public class BoardVO {
	private int seq; //0 => 50
	private String title; //null => "JdbcTemplate 테스트"
	private String writer; //null => "홍길동"
	private String content; //null => "JdbcTemplate  테스트"
	private Date regdate;//null
	private int cnt; //0
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) { //50
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) { //"JdbcTemplate 테스트")
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) { //"홍길동"
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) { //"JdbcTemplate  테스트"
		this.content = content;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	
	@Override
	public String toString() {
		return "BoardVO [seq=" + seq + ", title=" + title + ", writer=" + writer + ", content=" + content + ", regdate="
				+ regdate + ", cnt=" + cnt + "]";
	}

	
}
